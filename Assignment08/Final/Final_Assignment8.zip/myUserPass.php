<?php
	$username = "z1861700";
	$password = "1997Jun20";

?>
